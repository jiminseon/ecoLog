package model.service;

import java.util.ArrayList;

import model.Post;

public interface postService {
	
	public ArrayList<Post> postList();

}
