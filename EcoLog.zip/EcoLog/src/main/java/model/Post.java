package model;

public class Post {
	private int postNum; //게시글 번호
	private String title; //제목
	private String writer; //작성자
	private String category; //게시글 유형
	private String content; //게시글 내용
	private int visitCount; //조회수
	private String writeDate; //작성일
	
	public Post() {
		super();
	}
	
	public Post(int postNum, String title, String writer, String category, String writeDate) {
		super();
		this.postNum = postNum;
		this.title = title;
		this.writer = writer;
		this.category = category;
		this.writeDate = writeDate;
	}
	public Post(int postNum, String title, String writer, String category, String content, int visitCount,
			String writeDate) {
		super();
		this.postNum = postNum;
		this.title = title;
		this.writer = writer;
		this.category = category;
		this.content = content;
		this.visitCount = visitCount;
		this.writeDate = writeDate;
	}
	public int getPostNum() {
		return postNum;
	}
	public void setPostNum(int postNum) {
		this.postNum = postNum;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getVisitCount() {
		return visitCount;
	}
	public void setVisitCount(int visitCount) {
		this.visitCount = visitCount;
	}
	public String getWriteDate() {
		return writeDate;
	}
	public void setWriteDate(String writeDate) {
		this.writeDate = writeDate;
	}
	
	

}
